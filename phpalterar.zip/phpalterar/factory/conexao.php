<?php
    $server = "localhost";
    $user = "root";
    $senha = "";
    $dbname = "dbmarvel";
    $conn = mysqli_connect($server,$user,$senha, $dbname);
?>